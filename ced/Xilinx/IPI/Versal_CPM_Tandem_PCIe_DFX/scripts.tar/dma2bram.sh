#! /bin/bash
# Perform a MM DMA of random 32B to the BRAM at address 0x0

BDF=${BDF}

if [ -z "$BDF" ]; then
  echo "FATAL: Must hardcode BDF in script or set BDF env var"
  exit 1
fi

dma-to-device -d /dev/qdma$BDF-MM-0 -f /dev/urandom -s 32 -a 0x0 -c 1

