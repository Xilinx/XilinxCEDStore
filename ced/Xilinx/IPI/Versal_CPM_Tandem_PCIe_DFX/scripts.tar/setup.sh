#! /bin/bash
# Load the driver and set up and start the queues

lsmod | grep qdma &> /dev/null
if [ $? -eq 1 ]; then
  modprobe qdma-pf
  lsmod | grep qdma &> /dev/null
  if [ $? -eq 1 ]; then
    echo "ERR: The module failed to install"
    exit 1
  fi
fi

BDF=${BDF}
B=${BDF:0:2}
D=${BDF:2:2}
F=${BDF:4:1}

if [ -z "$B" ] || [ -z "$D" ] || [ -z "$F" ]; then
  echo "FATAL: Must hardcode BDF in script or set BDF env var"
  exit 1
fi

echo 3 > /sys/bus/pci/devices/0000:${B}:${D}.${F}/qdma/qmax

dma-ctl qdma${B}${D}${F} q add idx 0 mode mm dir h2c
dma-ctl qdma${B}${D}${F} q add idx 1 mode mm dir c2h
dma-ctl qdma${B}${D}${F} q add idx 2 mode st dir h2c

# No "fixed" option for DMA, so must set keyhole ("aperture_sz") to wrap
dma-ctl qdma${B}${D}${F} q start idx 0 dir h2c aperture_sz 4096
dma-ctl qdma${B}${D}${F} q start idx 1 dir c2h 
dma-ctl qdma${B}${D}${F} q start idx 2 dir h2c 

dma-ctl dev list
