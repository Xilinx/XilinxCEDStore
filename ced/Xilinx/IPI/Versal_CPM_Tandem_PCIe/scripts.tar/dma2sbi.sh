#! /bin/bash
# Perform a MM DMA of file $1 to the SBI. File should be a stage 2 .pdi or 
# a reconfigurable partition .pdi.

BDF=${BDF}

if [ -z "$BDF" ]; then
  echo "FATAL: Must hardcode BDF in script or set BDF env var"
  exit 1
fi

if [ $# -ne 1 ]; then
  echo "FATAL: Must specify PDI file to be transferred as first argument"
  exit 1
fi

FILE=$1
SIZE=$(stat --printf=%s $FILE)

dma-to-device -d /dev/qdma$BDF-MM-0 -f $FILE -s $SIZE -a 0x102100000 
