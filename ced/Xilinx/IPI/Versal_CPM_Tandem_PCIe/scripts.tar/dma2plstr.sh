#! /bin/bash
# Perform a single 64B streaming DMA to the PL
# !! MUST use 2022.2 release of QDMA driver !!

BDF=${BDF}

if [ -z "$BDF" ]; then
  echo "FATAL: Must hardcode BDF in script or set BDF env var"
  exit 1
fi

dma-to-device -d /dev/qdma$BDF-ST-2 -f /dev/urandom -s 64 -c 1
