#! /bin/bash
# Read the first 32B via MM DMA from the BRAM at address 0x0 into frombram.raw

BDF=${BDF}

if [ -z "$BDF" ]; then
  echo "FATAL: Must hardcode BDF in script or set BDF env var"
  exit 1
fi

dma-from-device -d /dev/qdma$BDF-MM-1 -f frombram.raw -s 32 -a 0x0 -c 1

echo "Here's what we got:"
hexdump frombram.raw | head
